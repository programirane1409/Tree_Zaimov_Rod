﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DurvetaZaimov
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private int br_id = 0;

        string connstr = " server=10.6.0.127;"
                + "port=3306;"
                + " user=PC1;"
                + " password=1111;"
                + " database=trees_zaimov";
        private void Form1_Load(object sender, EventArgs e)
        {
            MySqlConnection connect = new MySqlConnection(connstr);
            if (connect.State == 0)
            {
                connect.Open();
            }
            MessageBox.Show("Connection NOW opened");

            connect.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"{br_id}.Ime: {textBox1.Text},Ime na bg: {textBox2.Text}");
            string insertSQL = "INSERT INTO trees_zaimov.rod" +
                "(id,`name`,`name_bg`)" +
                "VALUES (@id,@name,@name_bg)";
            MySqlConnection connect = new MySqlConnection(connstr);
            if (connect.State == 0)
            {
                connect.Open();
            }
            MySqlCommand query = new MySqlCommand(insertSQL, connect);
            query.Parameters.AddWithValue("@id", br_id++);
            query.Parameters.AddWithValue("@name", textBox1.Text);
            query.Parameters.AddWithValue("@name_bg", textBox2.Text);

            query.ExecuteNonQuery();
            connect.Close();
        }
    }
}
